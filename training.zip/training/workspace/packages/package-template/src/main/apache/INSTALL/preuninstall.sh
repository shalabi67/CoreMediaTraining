#!/bin/bash

# $1 == 0 --> uninstall
# $1 == 1 --> update

#if [ $1 -eq 0 ]; then
#fi

#if [ $1 -eq 1 ]; then
#fi
