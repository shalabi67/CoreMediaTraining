#!/bin/sh
../../cmd-tools/cms-tools-application/target/cms-tools/bin/cm unlockcontentserver
