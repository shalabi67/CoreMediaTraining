#!/bin/sh
../../cmd-tools/mls-tools-application/target/mls-tools/bin/cm unlockcontentserver
