#!/bin/sh
../../cmd-tools/rls-tools-application/target/rls-tools/bin/cm unlockcontentserver
