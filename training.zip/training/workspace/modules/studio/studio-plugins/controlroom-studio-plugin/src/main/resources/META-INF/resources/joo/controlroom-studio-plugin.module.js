joo.loadModule("${project.groupId}", "${project.artifactId}");
coremediaEditorPlugins.push({
  name:"ControlRoom",
  mainClass:"com.coremedia.blueprint.studio.ControlRoomStudioPlugin"
});
