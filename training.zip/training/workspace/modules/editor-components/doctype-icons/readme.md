Doctype Icons
==================

Place your 64x64 doctype icons below ```src/main/resources/hox/corem/editor/doctype-icons/``` and your
32x32 doctype icons below ```src/main/resources/hox/corem/editor/doctype-icons/32x32```
