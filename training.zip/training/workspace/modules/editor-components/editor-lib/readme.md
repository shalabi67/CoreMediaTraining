Editor-lib
=====================

In this module you can put your Swing Editor customizations. Put java code below ```src/main/java``` and resources like
localizations below ```src/main/resources```

