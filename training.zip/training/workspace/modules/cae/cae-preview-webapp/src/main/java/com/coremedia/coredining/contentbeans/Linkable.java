package com.coremedia.coredining.contentbeans;

public interface Linkable {

	String getTitle();

}