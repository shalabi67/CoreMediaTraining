#!/bin/sh
mvn tomcat7:run-war
