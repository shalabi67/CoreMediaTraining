default['yum']['base']['managed']        = true
default['yum']['centosplus']['managed']  = false
default['yum']['updates']['managed']     = false
default['yum']['extras']['managed']      = false
default['yum']['contrib']['managed']     = false
default['yum']['base']['exclude']        = 'mysql-*'