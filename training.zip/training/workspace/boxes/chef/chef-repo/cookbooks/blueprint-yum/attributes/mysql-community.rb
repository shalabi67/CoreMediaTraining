default['blueprint']['yum']['mysql-community']['managed'] = true
default['yum']['mysql55-community']['http_caching'] = 'all'
