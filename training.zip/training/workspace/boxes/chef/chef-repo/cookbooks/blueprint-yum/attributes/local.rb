# the path of the local rpm repository
default['blueprint']['yum']['local']['path'] = '/var/tmp/rpm-repo'
# the URL from which to retrieve a repository archive, optional
default['blueprint']['yum']['local']['archive'] = ''
