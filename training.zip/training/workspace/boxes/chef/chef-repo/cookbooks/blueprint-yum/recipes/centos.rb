#
# Cookbook Name:: blueprint-yum
# Recipe:: centos
#
# Copyright (C) 2014
#
#

include_recipe 'yum-centos::default'
