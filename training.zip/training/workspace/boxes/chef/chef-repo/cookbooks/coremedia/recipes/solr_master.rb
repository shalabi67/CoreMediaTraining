coremedia_service "cm7-solr-master-tomcat"
