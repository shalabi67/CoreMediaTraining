Chef::Log.debug("setting verbose_logging to false")
Chef::Config[:verbose_logging] = false
