coremedia_service "cm7-solr-slave-tomcat"
