package com.coremedia.coredining.view;

import com.coremedia.coredining.contentbeans.HasViewVariant;
import com.coremedia.objectserver.view.RenderNode;
import com.coremedia.objectserver.view.RenderNodeDecorator;

public class ViewVariantRenderNodeDecorator implements RenderNodeDecorator {

  @Override
  public Object decorateBean(Object self, String view) {
	return self;
  }

  @Override
  public String decorateViewName(Object self, String view) {
    String decoratedViewName = view;

    if (self instanceof HasViewVariant) {
      String viewVariant = ((HasViewVariant) self).getViewVariant();
      if (viewVariant!=null) {
        decoratedViewName = (view==null) ? "" : view;
        decoratedViewName += "[" + viewVariant + "]";
      }
    }
    return decoratedViewName;
  }

  @Override
  public RenderNode decorateRenderNode(Object self, String view) {
    return new RenderNode(decorateBean(self, view), decorateViewName(self, view));
  }
}
