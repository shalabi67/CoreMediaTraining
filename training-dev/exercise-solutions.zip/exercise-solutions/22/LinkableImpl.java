package com.coremedia.coredining.contentbeans;

import java.util.List;

import com.coremedia.coredining.contentbeans.Linkable;
import com.coremedia.objectserver.beans.ContentBean;

/**
 *  Generated extension class for beans of document type "Linkable".
 */
public class LinkableImpl extends LinkableBase implements Linkable, HasViewVariant  {

  @Override
  public String getViewVariant() {
    List<? extends Symbol> views = getView();
    if (!views.isEmpty()) {
      Symbol view = views.get(0);
      if (view instanceof ContentBean) {
        return ((ContentBean) view).getContent().getName();
      }
    }
    return null;
  }
  
}
