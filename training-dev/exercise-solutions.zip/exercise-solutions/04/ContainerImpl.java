package com.coremedia.coredining.contentbeans;

import com.coremedia.coredining.contentbeans.Container;
import com.coremedia.coredining.contentbeans.ContainerBase;

/**
 *  Generated extension class for beans of document type "Container".
 */
public class ContainerImpl extends ContainerBase implements Container  {

  /*
   * DEVELOPER NOTE
   * You are invited to change this class by adding additional methods here.
   * Add them to the interface {@link com.coremedia.coredining.contentbeans.Container} to make them public.
   */
}
