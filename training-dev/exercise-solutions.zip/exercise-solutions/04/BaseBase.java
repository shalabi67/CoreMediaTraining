package com.coremedia.coredining.contentbeans;

import com.coremedia.cap.content.Content;
import com.coremedia.objectserver.beans.AbstractContentBean;

/**
 * Generated base class for beans of document type "Base".
 */
public abstract class BaseBase extends AbstractContentBean {

  /*
   * DEVELOPER NOTE
   * Change {@link com.coremedia.coredining.contentbeans.BaseImpl} instead of this class.
   */
}
