package com.coremedia.coredining.contentbeans;

import com.coremedia.coredining.contentbeans.ClientCode;
import com.coremedia.coredining.contentbeans.ClientCodeBase;

/**
 *  Generated extension class for beans of document type "ClientCode".
 */
public class ClientCodeImpl extends ClientCodeBase implements ClientCode  {

  /*
   * DEVELOPER NOTE
   * You are invited to change this class by adding additional methods here.
   * Add them to the interface {@link com.coremedia.coredining.contentbeans.ClientCode} to make them public.
   */
}
