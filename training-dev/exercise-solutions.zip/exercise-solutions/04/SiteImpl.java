package com.coremedia.coredining.contentbeans;

import com.coremedia.coredining.contentbeans.Site;
import com.coremedia.coredining.contentbeans.SiteBase;

/**
 *  Generated extension class for beans of document type "Site".
 */
public class SiteImpl extends SiteBase implements Site  {

  /*
   * DEVELOPER NOTE
   * You are invited to change this class by adding additional methods here.
   * Add them to the interface {@link com.coremedia.coredining.contentbeans.Site} to make them public.
   */
}
