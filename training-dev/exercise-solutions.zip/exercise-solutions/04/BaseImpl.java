package com.coremedia.coredining.contentbeans;

import com.coremedia.coredining.contentbeans.Base;
import com.coremedia.coredining.contentbeans.BaseBase;

/**
 *  Generated extension class for beans of document type "Base".
 */
public class BaseImpl extends BaseBase implements Base  {

  /*
   * DEVELOPER NOTE
   * You are invited to change this class by adding additional methods here.
   * Add them to the interface {@link com.coremedia.coredining.contentbeans.Base} to make them public.
   */
}
