package com.coremedia.coredining.contentbeans;

import com.coremedia.coredining.contentbeans.Settings;
import com.coremedia.coredining.contentbeans.SettingsBase;

/**
 *  Generated extension class for beans of document type "Settings".
 */
public class SettingsImpl extends SettingsBase implements Settings  {

  /*
   * DEVELOPER NOTE
   * You are invited to change this class by adding additional methods here.
   * Add them to the interface {@link com.coremedia.coredining.contentbeans.Settings} to make them public.
   */
}
