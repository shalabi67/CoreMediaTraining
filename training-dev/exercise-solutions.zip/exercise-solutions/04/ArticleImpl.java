package com.coremedia.coredining.contentbeans;

import com.coremedia.coredining.contentbeans.Article;
import com.coremedia.coredining.contentbeans.ArticleBase;

/**
 *  Generated extension class for beans of document type "Article".
 */
public class ArticleImpl extends ArticleBase implements Article  {

  /*
   * DEVELOPER NOTE
   * You are invited to change this class by adding additional methods here.
   * Add them to the interface {@link com.coremedia.coredining.contentbeans.Article} to make them public.
   */
}
