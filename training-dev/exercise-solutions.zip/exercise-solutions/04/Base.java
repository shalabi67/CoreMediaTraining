package com.coremedia.coredining.contentbeans;


/**
 * Generated interface for beans of document type "Base".
 */
public interface Base  {

  /*
   * DEVELOPER NOTE
   * Change the methods to narrow the public interface
   * of the {@link com.coremedia.coredining.contentbeans.BaseImpl} implementation bean.
   */

  /**
   * {@link com.coremedia.cap.content.ContentType#getName() Name of the ContentType} 'Base'
   */
  public static final String CONTENTTYPE_BASE = "Base";
}
