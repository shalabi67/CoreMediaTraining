package com.coremedia.coredining.contentbeans;

import com.coremedia.coredining.contentbeans.Symbol;
import com.coremedia.coredining.contentbeans.SymbolBase;

/**
 *  Generated extension class for beans of document type "Symbol".
 */
public class SymbolImpl extends SymbolBase implements Symbol  {

  /*
   * DEVELOPER NOTE
   * You are invited to change this class by adding additional methods here.
   * Add them to the interface {@link com.coremedia.coredining.contentbeans.Symbol} to make them public.
   */
}
