package com.coremedia.coredining.contentbeans;

import com.coremedia.coredining.contentbeans.PageLayout;
import com.coremedia.coredining.contentbeans.PageLayoutBase;

/**
 *  Generated extension class for beans of document type "PageLayout".
 */
public class PageLayoutImpl extends PageLayoutBase implements PageLayout  {

  /*
   * DEVELOPER NOTE
   * You are invited to change this class by adding additional methods here.
   * Add them to the interface {@link com.coremedia.coredining.contentbeans.PageLayout} to make them public.
   */
}
