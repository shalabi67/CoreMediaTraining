package com.coremedia.coredining.contentbeans;

import com.coremedia.coredining.contentbeans.Topic;
import com.coremedia.coredining.contentbeans.TopicBase;

/**
 *  Generated extension class for beans of document type "Topic".
 */
public class TopicImpl extends TopicBase implements Topic  {

  /*
   * DEVELOPER NOTE
   * You are invited to change this class by adding additional methods here.
   * Add them to the interface {@link com.coremedia.coredining.contentbeans.Topic} to make them public.
   */
}
