package com.coremedia.coredining.contentbeans;

import com.coremedia.coredining.contentbeans.Linkable;
import com.coremedia.coredining.contentbeans.LinkableBase;

/**
 *  Generated extension class for beans of document type "Linkable".
 */
public class LinkableImpl extends LinkableBase implements Linkable  {

  /*
   * DEVELOPER NOTE
   * You are invited to change this class by adding additional methods here.
   * Add them to the interface {@link com.coremedia.coredining.contentbeans.Linkable} to make them public.
   */
}
