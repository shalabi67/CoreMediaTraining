package com.coremedia.coredining.contentbeans;

import com.coremedia.coredining.contentbeans.Image;
import com.coremedia.coredining.contentbeans.ImageBase;

/**
 *  Generated extension class for beans of document type "Image".
 */
public class ImageImpl extends ImageBase implements Image  {

  /*
   * DEVELOPER NOTE
   * You are invited to change this class by adding additional methods here.
   * Add them to the interface {@link com.coremedia.coredining.contentbeans.Image} to make them public.
   */
}
