package com.coremedia.coredining.dao;

import java.util.Map;

/*
 * Copyright (c) 2013 CoreMedia AG, Hamburg. All rights reserved.
 */

public interface ArticleDAO {
    public Map<String, String> get(String identifier);
}
