export THIS_DIR=`pwd`/`dirname $0`

# === Content Management Server ===
$THIS_DIR/workspace/modules/cmd-tools/cms-tools-application/target/cms-tools/bin/cm unlockcontentserver
cd $THIS_DIR/workspace/modules/server/content-management-server-webapp/
mvn tomcat7:run-war > $THIS_DIR/content-management-server-webapp.out 2>&1 &
export SERVER_PID=$!
export KILL_SCRIPT=$THIS_DIR/stop-content-management-server-webapp.sh
echo "kill -9 $SERVER_PID; rm $KILL_SCRIPT" > $KILL_SCRIPT
echo Content Management Server started with PID $SERVER_PID

# #  === Master Live Server === 
# $THIS_DIR/workspace/modules/cmd-tools/mls-tools-application/target/mls-tools/bin/cm unlockcontentserver
# cd $THIS_DIR/workspace/modules/server/master-live-server-webapp/
# mvn tomcat7:run-war > $THIS_DIR/master-live-server-webapp.out 2>&1 &
# export SERVER_PID=$!
# export KILL_SCRIPT=$THIS_DIR/stop-master-live-server-webapp.sh
# echo "kill -9 $SERVER_PID; rm $KILL_SCRIPT" > $KILL_SCRIPT
# echo Master Live Server started with PID $SERVER_PID
# 
# #  === Replication Live Server ===
# $THIS_DIR/workspace/modules/cmd-tools/rls-tools-application/target/rls-tools/bin/cm unlockcontentserver
# cd $THIS_DIR/workspace/modules/server/replication-live-server-webapp/
# mvn tomcat7:run-war > $THIS_DIR/replication-live-server-webapp.out 2>&1 &
# export SERVER_PID=$!
# export KILL_SCRIPT=$THIS_DIR/stop-replication-live-server-webapp.sh
# echo "kill -9 $SERVER_PID; rm $KILL_SCRIPT" > $KILL_SCRIPT
# echo Replication Live Server started with PID $SERVER_PID
# 
# #  === Workflow Server ===
# cd $THIS_DIR/workspace/modules/server/workflow-server-webapp/
# mvn tomcat7:run-war > $THIS_DIR/workflow-server-webapp.out 2>&1 &
# export SERVER_PID=$!
# export KILL_SCRIPT=$THIS_DIR/stop-workflow-server-webapp.sh
# echo "kill -9 $SERVER_PID; rm $KILL_SCRIPT" > $KILL_SCRIPT
# echo Workflow Server started with PID $SERVER_PID
# 
# #  === User Changes Webapp ===
# cd $THIS_DIR/workspace/modules/server/user-changes-webapp/
# mvn tomcat7:run-war > $THIS_DIR/user-changes-webapp.out 2>&1 &
# export SERVER_PID=$!
# export KILL_SCRIPT=$THIS_DIR/stop-user-changes-server-webapp.sh
# echo "kill -9 $SERVER_PID; rm $KILL_SCRIPT" > $KILL_SCRIPT
# echo User Changes Webapp started with PID $SERVER_PID

cd $THIS_DIR

