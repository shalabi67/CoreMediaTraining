export THIS_DIR=`pwd`/`dirname $0`

echo === Start CAE Preview Web Application ===
echo
cd $THIS_DIR/workspace/modules/cae/cae-preview-webapp
mvn tomcat7:run > $THIS_DIR/cae-preview-webapp.out 2>&1 &
export SERVER_PID=$!
export KILL_SCRIPT=$THIS_DIR/stop-cae-preview-webapp.sh
echo "kill -9 $SERVER_PID; rm $KILL_SCRIPT" > $KILL_SCRIPT
echo Preview CAE started with PID $SERVER_PID
echo

echo === Start CAE Live Web Application ===
cd $THIS_DIR/workspace/modules/cae/cae-live-webapp
mvn tomcat7:run > $THIS_DIR/cae-live-webapp.out 2>&1 &
export SERVER_PID=$!
export KILL_SCRIPT=$THIS_DIR/stop-cae-live-webapp.sh
echo "kill -9 $SERVER_PID; rm $KILL_SCRIPT" > $KILL_SCRIPT
echo Live CAE started with PID $SERVER_PID
echo
cd $THIS_DIR

