#!/bin/sh
export THIS_DIR=`dirname $0`
export TOOLS_DIR=$THIS_DIR/workspace/modules/cmd-tools/cms-tools-application/target/cms-tools

echo === Import Content ===
$TOOLS_DIR/bin/cm serverimport -u admin -p admin -v -r $THIS_DIR/workspace/test-data/content

echo === Import Users ===
$TOOLS_DIR/bin/cm restoreusers -u admin -p admin -f $THIS_DIR/workspace/test-data/users/users.xml

echo === Done ===

