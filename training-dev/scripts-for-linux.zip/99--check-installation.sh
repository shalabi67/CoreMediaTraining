#!/bin/sh

echo === Check Installation ========

echo
echo === JAVA ======================
echo
echo JAVA_HOME = $JAVA_HOME
echo
java -version

echo   
echo === Maven =====================
echo
echo M2_HOME = $M2_HOME
echo MAVEN_OPTS = $MAVEN_OPTS
echo CATALINA_OPTS = $CATALINA_OPTS
echo
mvn --version
echo
   
echo   
echo === PostgreSQL ================
echo
psql --version

# echo    
# echo === PhantomJS =================
# echo
# echo PHANTOMJS_HOME = $PHANTOMJS_HOME
# echo
# phantomjs --version
# 
# echo
# echo === Vagrant ===================
# echo
# echo VAGRANT_HOME = $VAGRANT_HOME
# echo
# vagrant --version
# 
# echo
# echo --- Vagrant Plugins -----------
# echo
# vagrant plugin list
# 
# echo
# echo === Oracle Virtual Box ========
# echo
# echo VBOX_INSTALL_PATH = $VBOX_INSTALL_PATH
# echo
# vboxmanage --version
# 
# echo
# echo === ChefDK ====================
# echo
# echo CHEFDK_HOME = $CHEFDK_HOME
# echo
# chef --version

echo
echo === DONE ======================
