#!/bin/sh
export THIS_DIR=`dirname $0`
export TOOLS_DIR=$THIS_DIR/workspace/modules/editor-components/editor/target/editor

$TOOLS_DIR/bin/cm editor &

