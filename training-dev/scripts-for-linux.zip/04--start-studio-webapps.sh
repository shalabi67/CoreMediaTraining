export THIS_DIR=`pwd`/`dirname $0`

echo === Solr Webapp ===
cd $THIS_DIR/workspace/modules/search/solr-webapp
mvn tomcat7:run-war > $THIS_DIR/solr-webapp.out 2>&1 &
export SERVER_PID=$!
export KILL_SCRIPT=$THIS_DIR/stop-solr-webapp.sh
echo "kill -9 $SERVER_PID; rm $KILL_SCRIPT" > $KILL_SCRIPT
echo Solr Webapp started with PID $SERVER_PID
echo

echo === Content Feeder Webapp ===
cd $THIS_DIR/workspace/modules/search/content-feeder-webapp
mvn tomcat7:run > $THIS_DIR/content-feeder-webapp.out 2>&1 &
export SERVER_PID=$!
export KILL_SCRIPT=$THIS_DIR/stop-content-feeder-webapp.sh
echo "kill -9 $SERVER_PID; rm $KILL_SCRIPT" > $KILL_SCRIPT
echo Content Feeder Webapp started with PID $SERVER_PID

echo === Studio Webapp ===
cd $THIS_DIR/workspace/modules/studio/studio-webapp
mvn tomcat7:run > $THIS_DIR/content-feeder-webapp.out 2>&1 &
export SERVER_PID=$!
export KILL_SCRIPT=$THIS_DIR/stop-studio-webapp.sh
echo "kill -9 $SERVER_PID; rm $KILL_SCRIPT" > $KILL_SCRIPT
echo Studio Webapp started with PID $SERVER_PID

echo === Done ===

