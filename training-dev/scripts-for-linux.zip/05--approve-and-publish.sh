#!/bin/sh
export THIS_DIR=`dirname $0`
export TOOLS_DIR=$THIS_DIR/workspace/modules/cmd-tools/cms-tools-application/target/cms-tools

echo === Approve and Publish imported content ===
echo
$TOOLS_DIR/bin/cm approve -u admin -p admin -t /Sites /Themes /Settings
$TOOLS_DIR/bin/cm bulkpublish -u admin -p admin -a -b -c -f /Sites /Themes /Settings
echo
echo === Done ===

