export THIS_DIR=`dirname $0`

# Build Workspace
cd $THIS_DIR/workspace
mvn clean install -DskipTests

